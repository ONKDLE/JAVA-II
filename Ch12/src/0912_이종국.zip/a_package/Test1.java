package a_package;

public class Test1 {
	public int sum(int a, int b) {
		return a+b;
	}
}
